#!/usr/bin/env python3

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import actionlib
import time

#from math import pi
#from std_msgs.msg import String
#from moveit_commander.conversions import pose_to_list
## END_SUB_TUTORIAL



import rospy
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse


import rospy
from hrwros_gazebo.msg import LogicalCameraImage
import tf2_ros
import tf2_geometry_msgs
import geometry_msgs
import time


def logical_camera_callback(data):
  
  
  # Check if the logical camera has seen our box which has the name 'object'.
  #if (data.models[-1].type == 'object'):
 

  rospy.loginfo("I heard %s", data.models)
  print('*** èèèèè  ')
  
  if (data.models[-1].type == 'simple_cube'):  
      # Create a pose stamped message type from the camera image topic.
      object_pose = geometry_msgs.msg.PoseStamped()
      #object_pose.header.stamp = rospy.Time.now()
      object_pose.header.frame_id = "logical_camera_frame"
      object_pose.pose.position.x = data.models[-1].pose.position.x
      object_pose.pose.position.y = data.models[-1].pose.position.y
      object_pose.pose.position.z = data.models[-1].pose.position.z
      object_pose.pose.orientation.x = data.models[-1].pose.orientation.x
      object_pose.pose.orientation.y = data.models[-1].pose.orientation.y
      object_pose.pose.orientation.z = data.models[-1].pose.orientation.z
      object_pose.pose.orientation.w = data.models[-1].pose.orientation.w

      object_world_pose = tf_buffer.transform(object_pose, "world")
      print('*** èèèèè ciclo ')

      rospy.loginfo('object simple box')
        
      rospy.loginfo('Pose of the object in the world reference frame is: %s', object_world_pose)
      rospy.loginfo('Pose of the object in the logical camera reference frame is: %s', object_pose)

  time.sleep(5)
  print('*** fp calc shutdown')
  rospy.signal_shutdown('Successfully transformed pose.')
  print('*** fp calc shutdown')
  
  time.sleep(2)

  
  print('*** fp end sub')


def attach(parent_model, parent_link, child_model, child_link):
  ## First initialize `moveit_commander`_ and a `rospy`_ node:
  ## rospy.init_node('demo_attach_links1')
  rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
  attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                   Attach)
  attach_srv.wait_for_service()
  rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

  # Link them
  rospy.loginfo("Attaching cube1 and cube2")
  req = AttachRequest()
  req.model_name_1 = parent_model
  req.link_name_1 = parent_link
  req.model_name_2 = child_model
  req.link_name_2 = child_link
  
  attach_srv.call(req)  
    # From the shell:

def detach(parent_model, parent_link, child_model, child_link):
  ## First initialize `moveit_commander`_ and a `rospy`_ node:
  ## rospy.init_node('demo_detach_links1')
  rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
  attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                  Attach)
  attach_srv.wait_for_service()
  rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

  # Link them
  rospy.loginfo("Detaching cube1 and cube2")
  req = AttachRequest()
  req.model_name_1 = parent_model
  req.link_name_1 = parent_link
  req.model_name_2 = child_model
  req.link_name_2 = child_link
  
  attach_srv.call(req)
 





def simple_pick_place():
  ## First initialize `moveit_commander`_ and a `rospy`_ node:
  moveit_commander.roscpp_initialize(sys.argv)
  rospy.init_node('simple_pick_place', anonymous=True)
  
  

  robot_group = moveit_commander.MoveGroupCommander("arm_group")

  robot_client = actionlib.SimpleActionClient('execute_trajectory', moveit_msgs.msg.ExecuteTrajectoryAction)
  robot_client.wait_for_server()
  rospy.loginfo('Execute trajectory server is availabe for the robot')


  robot_group.set_named_target("zero")                                                #robot_plan_home = robot_group.plan()
  plan_success, robot_plan_home, planning_time, error_code = robot_group.plan()       ## Create a goal message object for the action server.
  robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()                                ## Update the trajectory in the goal message.
  robot_goal.trajectory = robot_plan_home                                             ## Send the goal to the action server.
  robot_client.send_goal(robot_goal)
  robot_client.wait_for_result()

  ## Cartesian Paths
  ## ^^^^^^^^^^^^^^^
  ## You can plan a cartesian path directly by specifying a list of waypoints
  ## for the end-effector to go through.
  waypoints = []
  # start with the current pose
  current_pose = robot_group.get_current_pose()
  rospy.sleep(0.5)
  current_pose = robot_group.get_current_pose()

  

  robot_group.clear_pose_targets()
  current_joints = robot_group.get_current_joint_values()
  rospy.sleep(0.5)
  current_joints = robot_group.get_current_joint_values()
  

  print(current_pose)
  print(current_joints)

  print("*************************")
  print("*************************")

  
  print("mi sposto alla posizione in giunto")
  group_variable_values = robot_group.get_current_joint_values()

  group_variable_values[0] = 1.5
  group_variable_values[1] = -1
  group_variable_values[2] = 1
  group_variable_values[3] = 0
  group_variable_values[4] = 1
  group_variable_values[5] = 0
  robot_group.set_joint_value_target(group_variable_values)

  
  robot_plan_home = robot_group.plan()
  plan_success, robot_plan_home, planning_time, error_code = robot_group.plan()
  ## Create a goal message object for the action server.
  robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
  ## Update the trajectory in the goal message.
  robot_goal.trajectory = robot_plan_home
  ## Send the goal to the action server.
  robot_client.send_goal(robot_goal)
  robot_client.wait_for_result()

  rospy.sleep(1)
  print("*************************")
  print("*************************")



  ## create linear offsets to the current pose
  new_eef_pose = geometry_msgs.msg.Pose()
  grasp_eef_pose = geometry_msgs.msg.Pose()
  ungrasp_eef_pose = geometry_msgs.msg.Pose()


  # Manual offsets because we don't have a camera to detect objects yet.
  # new_eef_pose.position.x = current_pose.pose.position.x + 0.10
  # new_eef_pose.position.y = current_pose.pose.position.y - 0.20
  # new_eef_pose.position.z = current_pose.pose.position.z - 0.20# 

  new_eef_pose.position.x = 0.2
  new_eef_pose.position.y = 0.6
  new_eef_pose.position.z = 0.6
  new_eef_pose.orientation.x = 1
  new_eef_pose.orientation.y = 0
  new_eef_pose.orientation.z = 0
  new_eef_pose.orientation.w = 0

  # Grasping point.
  grasp_eef_pose.position.x = 0.19853600832171103
  grasp_eef_pose.position.y = 0.5997874011367494
  grasp_eef_pose.position.z = 0.12479861633402056+0.2
  grasp_eef_pose.orientation.x = 1
  grasp_eef_pose.orientation.y = 0
  grasp_eef_pose.orientation.z = 0
  grasp_eef_pose.orientation.w = 0



  # start with the current pose
  current_pose = robot_group.get_current_pose()
  rospy.sleep(0.5)
  current_pose = robot_group.get_current_pose()

  

  # Retain orientation of the current pose.
  new_eef_pose.orientation = copy.deepcopy(current_pose.pose.orientation)
  new_eef_pose.position = copy.deepcopy(current_pose.pose.position)
  
  rospy.sleep(0.5)

  new_eef_pose.position.x = new_eef_pose.position.x+0
  new_eef_pose.position.y = new_eef_pose.position.y+0.1
  new_eef_pose.position.z = new_eef_pose.position.z-0.1
  

  #waypoints.clear()
  waypoints = []
  waypoints.append(new_eef_pose)
  waypoints.append(grasp_eef_pose)
  rospy.sleep(0.5)
  
  #waypoints.append(current_pose.pose)
  

  print(new_eef_pose.position)
  print(current_pose.pose.position)

  print(waypoints)

  print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
  
  ## We want the cartesian path to be interpolated at a resolution of 1 cm
  ## which is why we will specify 0.01 as the eef_step in cartesian
  ## translation.  We will specify the jump threshold as 0.0, effectively
  ## disabling it.
  fraction = 0.0
  for count_cartesian_path in range(0,3):
    if fraction < 1.0:
      (plan_cartesian, fraction) = robot_group.compute_cartesian_path(
                                   waypoints,   # waypoints to follow
                                   0.01,        # eef_step
                                   0.0)         # jump_threshold
    else:
      break

  robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
  robot_goal.trajectory = plan_cartesian
  robot_client.send_goal(robot_goal)
  robot_client.wait_for_result()
  


  print("arrivo al punto di prelievo")
  
  print("gofa_arm_urdf")
  attach("robot_arm","link06_rev6","simple_cube","box")

  
  
  print("gofa_arm_urdf")
  

  current_pose = robot_group.get_current_pose()
  rospy.sleep(0.1)
  current_pose = robot_group.get_current_pose()

  print(current_pose) 

  print("gofa_arm_urdf")
  # Grasping point.
  # ungrasp_eef_pose.position.x = -0.4
  # ungrasp_eef_pose.position.y = 0.6
  # ungrasp_eef_pose.position.z = 0.6
  # ungrasp_eef_pose.orientation.x = 1
  # ungrasp_eef_pose.orientation.y = 0
  # ungrasp_eef_pose.orientation.z = 0
  # ungrasp_eef_pose.orientation.w = 0

  # new_eef_pose.position.z = current_pose.pose.position.z - 0.20# 

  new_eef_pose.position.x = -0.4
  new_eef_pose.position.y = 0.6
  new_eef_pose.position.z = 0.6
  new_eef_pose.orientation.x = 1
  new_eef_pose.orientation.y = 0
  new_eef_pose.orientation.z = 0
  new_eef_pose.orientation.w = 0

  # Grasping point.
  grasp_eef_pose.position.x = -0.4
  grasp_eef_pose.position.y = 0.6
  grasp_eef_pose.position.z = 0.3
  grasp_eef_pose.orientation.x = 1
  grasp_eef_pose.orientation.y = 0
  grasp_eef_pose.orientation.z = 0
  grasp_eef_pose.orientation.w = 0

  

  
  
  waypoints.clear()
  waypoints = []

  waypoints.append(new_eef_pose)
  waypoints.append(grasp_eef_pose)
  
  #waypoints.append(current_pose.pose)
  

  

  print(waypoints)

  print(new_eef_pose.position)
  print(ungrasp_eef_pose.position)
  
  #waypoints.append(current_pose.pose)
  


  ## We want the cartesian path to be interpolated at a resolution of 1 cm
  ## which is why we will specify 0.01 as the eef_step in cartesian
  ## translation.  We will specify the jump threshold as 0.0, effectively
  ## disabling it.
  fraction = 0.0
  for count_cartesian_path in range(0,3):
    if fraction < 1.0:
      (plan_cartesian, fraction) = robot_group.compute_cartesian_path(
                                   waypoints,   # waypoints to follow
                                   0.01,        # eef_step
                                   0.0)         # jump_threshold
    else:
      break

  robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
  robot_goal.trajectory = plan_cartesian
  robot_client.send_goal(robot_goal)
  robot_client.wait_for_result()


  
  detach("robot_arm","link06_rev6","simple_cube","box")

  
  robot_group.set_named_target("home")
  #robot_plan_home = robot_group.plan()
  plan_success, robot_plan_home, planning_time, error_code = robot_group.plan()
  ## Create a goal message object for the action server.
  robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
  ## Update the trajectory in the goal message.
  robot_goal.trajectory = robot_plan_home
  ## Send the goal to the action server.
  robot_client.send_goal(robot_goal)
  robot_client.wait_for_result()
  
  
  ## When finished shut down moveit_commander.



  moveit_commander.roscpp_shutdown()




if __name__=='__main__':
  try:
    
    simple_pick_place()

    #rospy.spin()
  except rospy.ROSInterruptException:
    pass
