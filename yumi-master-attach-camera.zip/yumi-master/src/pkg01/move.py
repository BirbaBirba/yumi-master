#!/usr/bin/env python3

import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import actionlib
import time
from tf import TransformListener

#from math import pi
#from std_msgs.msg import String
#from moveit_commander.conversions import pose_to_list
## END_SUB_TUTORIAL



import rospy
from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse


import rospy
from hrwros_gazebo.msg import LogicalCameraImage
import tf2_ros
import tf2_geometry_msgs
import geometry_msgs
import time


def attach(parent_model, parent_link, child_model, child_link):
  ## First initialize `moveit_commander`_ and a `rospy`_ node:
  ## rospy.init_node('demo_attach_links1')
  rospy.loginfo("Creating ServiceProxy to /link_attacher_node/attach")
  attach_srv = rospy.ServiceProxy('/link_attacher_node/attach',
                                   Attach)
  attach_srv.wait_for_service()
  rospy.loginfo("Created ServiceProxy to /link_attacher_node/attach")

  # Link them
  rospy.loginfo("Attaching cube1 and cube2")
  req = AttachRequest()
  req.model_name_1 = parent_model
  req.link_name_1 = parent_link
  req.model_name_2 = child_model
  req.link_name_2 = child_link
  
  attach_srv.call(req)  
    # From the shell:

def detach(parent_model, parent_link, child_model, child_link):
  ## First initialize `moveit_commander`_ and a `rospy`_ node:
  ## rospy.init_node('demo_detach_links1')
  rospy.loginfo("Creating ServiceProxy to /link_attacher_node/detach")
  attach_srv = rospy.ServiceProxy('/link_attacher_node/detach',
                                  Attach)
  attach_srv.wait_for_service()
  rospy.loginfo("Created ServiceProxy to /link_attacher_node/detach")

  # Link them
  rospy.loginfo("Detaching cube1 and cube2")
  req = AttachRequest()
  req.model_name_1 = parent_model
  req.link_name_1 = parent_link
  req.model_name_2 = child_model
  req.link_name_2 = child_link
  
  attach_srv.call(req)

def move_robot():
      moveit_commander.roscpp_initialize(sys.argv)
      rospy.init_node('simple_pick_place', anonymous=True)

      # INITIALIZE CAMERA VARIABLES
      print ("***************")
      tf = TransformListener()
      tf.waitForTransform('/base_footprint','/logical_camera_simple_cube_frame',rospy.Time(), rospy.Duration(4.0))
      (trans, rot) = tf.lookupTransform('/base_footprint','/logical_camera_simple_cube_frame', rospy.Time())
      print (trans,rot)
      print ("***************")
      

      robot_right_arm = moveit_commander.MoveGroupCommander("right_arm")
      robot_left_arm = moveit_commander.MoveGroupCommander("left_arm")

      robot_client = actionlib.SimpleActionClient('execute_trajectory', moveit_msgs.msg.ExecuteTrajectoryAction)
      robot_client.wait_for_server()
      rospy.loginfo('Execute trajectory server is availabe for the robot')


      robot_right_arm.set_named_target("zero_r")   
      plan_success, robot_plan_home, planning_time, error_code = robot_right_arm.plan()       ## Create a goal message object for the action server.
      robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()                                ## Update the trajectory in the goal message.
      robot_goal.trajectory = robot_plan_home                                             ## Send the goal to the action server.
      robot_client.send_goal(robot_goal)
      robot_client.wait_for_result()

      robot_left_arm.set_named_target("zero_l")   
      plan_success, robot_plan_home, planning_time, error_code = robot_left_arm.plan()       ## Create a goal message object for the action server.
      robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()                                ## Update the trajectory in the goal message.
      robot_goal.trajectory = robot_plan_home                                             ## Send the goal to the action server.
      robot_client.send_goal(robot_goal)
      robot_client.wait_for_result()


      ## GO TO SCANN POINT R & L
      """
      robot_right_arm.set_named_target("scan_r")   
      plan_success, robot_plan_home, planning_time, error_code = robot_right_arm.plan()       ## Create a goal message object for the action server.
      robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()                                ## Update the trajectory in the goal message.
      robot_goal.trajectory = robot_plan_home                                             ## Send the goal to the action server.
      robot_client.send_goal(robot_goal)
      robot_client.wait_for_result()

      robot_left_arm.set_named_target("scan_l")   
      plan_success, robot_plan_home, planning_time, error_code = robot_left_arm.plan()       ## Create a goal message object for the action server.
      robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()                                ## Update the trajectory in the goal message.
      robot_goal.trajectory = robot_plan_home                                             ## Send the goal to the action server.
      robot_client.send_goal(robot_goal)
      robot_client.wait_for_result()
      """

      waypoints = []
      current_pose = robot_right_arm.get_current_pose()
      rospy.sleep(0.5)
      current_pose = robot_right_arm.get_current_pose()

      robot_right_arm.clear_pose_targets()
      current_joints = robot_right_arm.get_current_joint_values()
      rospy.sleep(0.5)
      current_joints = robot_right_arm.get_current_joint_values()


      #group_variable_values = robot_right_arm.get_current_joint_values()
      new_eef_pose = geometry_msgs.msg.Pose()
      grasp_eef_pose = geometry_msgs.msg.Pose()
      ungrasp_eef_pose = geometry_msgs.msg.Pose()

      new_eef_pose.position.x = 0.2
      new_eef_pose.position.y = 0.6
      new_eef_pose.position.z = 0.6
      new_eef_pose.orientation.x = 1
      new_eef_pose.orientation.y = 0
      new_eef_pose.orientation.z = 0
      new_eef_pose.orientation.w = 0

      # Grasping point.
      grasp_eef_pose.position.x = trans[0]
      grasp_eef_pose.position.y = trans[1]
      grasp_eef_pose.position.z = trans[2]+0.05+0.15
      
      grasp_eef_pose.orientation.x = rot[0]
      grasp_eef_pose.orientation.y = rot[1]
      grasp_eef_pose.orientation.z = rot[2]
      grasp_eef_pose.orientation.w = rot[3]

      current_pose = robot_group.get_current_pose()
      rospy.sleep(0.5)
      current_pose = robot_group.get_current_pose()

      new_eef_pose.orientation = copy.deepcopy(current_pose.pose.orientation)
      new_eef_pose.position = copy.deepcopy(current_pose.pose.position)
      
      rospy.sleep(0.5)

      new_eef_pose.position.x = new_eef_pose.position.x+0
      new_eef_pose.position.y = new_eef_pose.position.y+0.1
      new_eef_pose.position.z = new_eef_pose.position.z-0.1
      

      #waypoints.clear()
      waypoints = []
      waypoints.append(new_eef_pose)
      waypoints.append(grasp_eef_pose)
      rospy.sleep(0.5)

      fraction = 0.0
      for count_cartesian_path in range(0,3):
            if fraction < 1.0:
                  (plan_cartesian, fraction) = robot_group.compute_cartesian_path(
                                          waypoints,   # waypoints to follow
                                          0.01,        # eef_step
                                          0.0)         # jump_threshold
            else:
                  break

      robot_goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
      robot_goal.trajectory = plan_cartesian
      robot_client.send_goal(robot_goal)
      robot_client.wait_for_result()


if __name__ == '__main__':
      try:
            move_robot()
      except rospy.ROSInterruptException:
            pass



""" CUBE
position: 
    x: 0.7750018943126804
    y: 3.5941270285063455e-07
    z: 4.502323660615648e-06
  orientation: 
    x: -0.7070858848539924
    y: -5.186330444191254e-06
    z: -9.407842480610357e-06
    w: 0.7071276768199934
    """