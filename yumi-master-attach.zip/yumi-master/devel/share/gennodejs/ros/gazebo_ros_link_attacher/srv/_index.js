
"use strict";

let Attach = require('./Attach.js')
let Attach copy = require('./Attach copy.js')

module.exports = {
  Attach: Attach,
  Attach copy: Attach copy,
};
